-- Creo le tabelle --

CREATE TABLE Product (
    ProductID INT AUTO_INCREMENT,
    Name VARCHAR(255) NOT NULL,
    Category VARCHAR(255),
    PRIMARY KEY (ProductID)
);

CREATE TABLE Region (
    RegionID INT AUTO_INCREMENT,
    Name VARCHAR(255) NOT NULL,
    PRIMARY KEY (RegionID)
);

CREATE TABLE Sales (
    SalesID INT AUTO_INCREMENT,
    ProductID INT,
    RegionID INT,
    SaleDate DATE,
    Amount DECIMAL(10 , 2 ),
    PRIMARY KEY (SalesID),
    FOREIGN KEY (ProductID)
        REFERENCES Product (ProductID),
    FOREIGN KEY (RegionID)
        REFERENCES Region (RegionID)
);

-- Popolo le tabelle --

INSERT INTO Product (Name, Category) VALUES
('Follettino', 'Bambola'),
('Deadpool', 'Bambola'),
('Barbie Principessa', 'Bambola'),
('Ken Esploratore', 'Bambola'),
('Baby Alive', 'Bambola'),
('MachineMicro', 'Automobilina'),
('Formula 1', 'Automobilina'),
('Monster Truck', 'Automobilina'),
('Macchina da corsa', 'Automobilina'),
('Carramba', 'Automobilina'),
('Monopolio', 'Giochi da tavolo'),
('Stercoraro', 'Giochi da tavolo'),
('Riskio', 'Giochi da tavolo'),
('Cluero', 'Giochi da tavolo'),
('Triviale Pursuit', 'Giochi da tavolo'),
('Puzzle 1000 pezzi', 'Puzzle'),
('Puzzle 500 pezzi', 'Puzzle'),
('Puzzle 2000 pezzi', 'Puzzle'),
('Wario Kart 8', 'Videogiochi'),
('The Legend of Zelda', 'Videogiochi');

INSERT INTO Region (Name) VALUES
('Europa'),
('Nord America'),
('Sud America'),
('Asia'),
('Africa'),
('Oceania');

INSERT INTO Sales (ProductID, RegionID, SaleDate, Amount) VALUES
(1, 1, '2023-01-15', 19.99),
(2, 2, '2023-02-20', 24.99),
(1, 3, '2023-03-10', 19.99),
(3, 1, '2023-01-25', 14.99),
(2, 3, '2023-04-05', 24.99),
(4, 4, '2023-05-12', 29.99),
(5, 5, '2023-06-18', 34.99),
(6, 1, '2023-07-22', 39.99),
(7, 2, '2023-08-15', 44.99),
(8, 3, '2023-09-21', 49.99),
(9, 4, '2023-10-30', 18.99),
(10, 5, '2023-11-05', 23.99),
(11, 1, '2023-12-11', 28.99),
(12, 2, '2023-01-16', 33.99),
(13, 3, '2023-02-21', 38.99),
(14, 4, '2023-03-27', 43.99),
(15, 5, '2023-04-08', 48.99),
(16, 1, '2023-05-14', 17.99),
(17, 2, '2023-06-19', 22.99),
(18, 3, '2023-07-23', 27.99),
(19, 4, '2023-08-16', 32.99),
(20, 5, '2023-09-22', 37.99),
(1, 1, '2023-10-31', 42.99),
(2, 2, '2023-11-06', 47.99),
(3, 3, '2023-12-12', 16.99),
(4, 4, '2023-01-17', 21.99),
(5, 5, '2023-02-22', 26.99),
(6, 1, '2023-03-28', 31.99),
(7, 2, '2023-04-09', 36.99),
(8, 3, '2023-05-15', 41.99),
(9, 4, '2023-06-20', 46.99),
(10, 5, '2023-07-24', 15.99),
(11, 1, '2023-08-17', 20.99),
(12, 2, '2023-09-23', 25.99),
(13, 3, '2023-10-01', 30.99),
(14, 4, '2023-11-07', 35.99),
(15, 5, '2023-12-13', 40.99),
(16, 1, '2023-01-18', 45.99),
(17, 2, '2023-02-23', 14.99),
(18, 3, '2023-03-29', 19.99),
(19, 4, '2023-04-10', 24.99),
(20, 5, '2023-05-16', 29.99),
(1, 1, '2023-06-21', 34.99),
(2, 2, '2023-07-25', 39.99),
(3, 3, '2023-08-18', 44.99),
(4, 4, '2023-09-24', 49.99);

-- Verifica univocità PK per Product
SELECT 
    ProductID, COUNT(*)
FROM
    Product
GROUP BY ProductID
HAVING COUNT(*) > 1

-- Verifica univocità PK per Region
SELECT 
    RegionID, COUNT(*)
FROM
    Region
GROUP BY RegionID
HAVING COUNT(*) > 1

-- Verifica univocità PK per Sales
SELECT 
    SalesID, COUNT(*)
FROM
    Sales
GROUP BY SalesID
HAVING COUNT(*) > 1

-- Creo l'elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno--

SELECT p.Name AS ProductName, YEAR(s.SaleDate) AS Year, SUM(s.Amount) AS TotalRevenue
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
GROUP BY p.Name, YEAR(s.SaleDate);

-- Indico il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente --

SELECT r.Name AS RegionName, YEAR(s.SaleDate) AS Year, SUM(s.Amount) AS TotalRevenue
FROM Sales s
JOIN Region r ON s.RegionID = r.RegionID
GROUP BY r.Name, YEAR(s.SaleDate)
ORDER BY Year, TotalRevenue DESC;

-- Qual è la categoria di articoli maggiormente richiesta dal mercato? --

SELECT p.Category, COUNT(s.SalesID) AS TotalSales
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
GROUP BY p.Category
ORDER BY TotalSalesaless DESC
LIMIT 1;

-- Quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.--
-- Approccio 1--

SELECT p.Name
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
WHERE s.SalesID IS NULL;

-- Approccio 2--

CREATE VIEW Prodotti_invenduti_1 AS 
SELECT p.Name AS ProductName
FROM Product p
WHERE p.ProductID NOT IN (
    SELECT s.ProductID 
    FROM Sales s
);

-- elenco dei prodotti con la rispettiva ultima data di vendita.--

SELECT p.Name AS ProductName, MAX(s.SaleDate) AS LastSaleDate
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
GROUP BY p.Name;